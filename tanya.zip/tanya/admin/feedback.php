<?php
// Database connection settings
$servername = "localhost"; // Your database server
$username = "root";        // Your database username
$password = "";            // Your database password
$dbname = "therapists_appointment_db"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete Feedback Logic
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $delete_sql = "DELETE FROM feedback WHERE id = $id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Feedback deleted successfully!'); window.location.href='view_feedback.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Query to fetch all feedback
$sql = "SELECT id, name, email, rating, therapists, comments, created_at FROM feedback";
$result = $conn->query($sql);

// Start the HTML
echo '<!DOCTYPE html>';
echo '<html lang="en">';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '<title>Feedback Display</title>';
echo '<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">';
echo '<style>';
echo 'body { font-family: "Roboto", sans-serif; background-color: #fff; color: #333; margin: 0; padding: 0; }';
echo 'header { background-color: #000; color: #fff; padding: 20px 0; text-align: center; font-size: 24px; }';
echo 'main { width: 80%; margin: 20px auto; padding: 20px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }';
echo 'table { width: 100%; border-collapse: collapse; margin-top: 20px; }';
echo 'th, td { padding: 12px 15px; text-align: left; border: 1px solid #333; }';
echo 'th { background-color: #333; color: #fff; font-weight: 700; }';
echo 'td { background-color: #f9f9f9; }';
echo 'tr:nth-child(even) { background-color: #fff; }';
echo 'tr:hover { background-color: #f1f1f1; }';
echo '.button { background-color: #333; color: #fff; border: none; padding: 8px 16px; cursor: pointer; border-radius: 5px; font-size: 14px; }';
echo '.button:hover { background-color: #555; }';
echo 'footer { text-align: center; padding: 10px 0; background-color: #000; color: #fff; font-size: 14px; margin-top: 30px; }';
echo '</style>';
echo '</head>';
echo '<body>';

echo '<header>';
echo 'Customers Feedback';
echo '</header>';

echo '<main>';

echo '<h2>All Feedback</h2>';

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Start the HTML table
    echo '<table>';
    echo '<tr><th>ID</th><th>Name</th><th>Email</th><th>Rating</th><th>Therapists</th><th>Comments</th><th>Submitted At</th><th>Actions</th></tr>';

    // Fetch and display each row
    while($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row["id"] . '</td>';
        echo '<td>' . $row["name"] . '</td>';
        echo '<td>' . $row["email"] . '</td>';
        echo '<td>' . $row["rating"] . '</td>';
        echo '<td>' . $row["therapists"] . '</td>';
        echo '<td>' . nl2br($row["comments"]) . '</td>'; // Preserve newlines in comments
        echo '<td>' . $row["created_at"] . '</td>';
        
        // Edit and Delete Buttons
        echo '<td>';
        echo '<a href="edit_feedback.php?id=' . $row["id"] . '"><button class="button">Edit</button></a>';
        echo ' ';
        echo '<a href="?delete=' . $row["id"] . '" onclick="return confirm(\'Are you sure you want to delete this feedback?\');"><button class="button">Delete</button></a>';
        echo '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo "<p>No feedback available.</p>";
}

echo '</main>';



echo '</body>';
echo '</html>';

// Close the connection
$conn->close();
?>
