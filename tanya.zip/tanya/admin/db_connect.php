<?php 

$conn= new mysqli('localhost','root','','therapists_appointment_db')or die("Could not connect to mysql".mysqli_error($con));
